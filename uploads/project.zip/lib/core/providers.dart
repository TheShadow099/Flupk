import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive/hive.dart';
import 'package:nebula/core/constants.dart';
import 'package:nebula/data/models/history_item.dart';
import 'package:nebula/data/models/tab_model.dart';
import 'package:nebula/data/services/history_service.dart';
import 'package:nebula/data/services/settings_service.dart';
import 'package:uuid/uuid.dart';


// --- Settings Providers ---
final settingsServiceProvider = Provider<SettingsService>((ref) {
  final box = Hive.box<String>(settingsBoxName);
  return SettingsService(box);
});

final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) {
  return ThemeModeNotifier(ref.watch(settingsServiceProvider));
});

class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  final SettingsService _settingsService;
  ThemeModeNotifier(this._settingsService) : super(_settingsService.getThemeMode());

  void setThemeMode(ThemeMode mode) {
    _settingsService.setThemeMode(mode);
    state = mode;
  }
}

final saveHistoryProvider = StateNotifierProvider<SaveHistoryNotifier, bool>((ref) {
  return SaveHistoryNotifier(ref.watch(settingsServiceProvider));
});

class SaveHistoryNotifier extends StateNotifier<bool> {
  final SettingsService _settingsService;
  SaveHistoryNotifier(this._settingsService) : super(_settingsService.getSaveHistoryEnabled());

  void setSaveHistory(bool enabled) {
    _settingsService.setSaveHistoryEnabled(enabled);
    state = enabled;
  }
}

final desktopModeProvider = StateNotifierProvider<DesktopModeNotifier, bool>((ref) {
  return DesktopModeNotifier(ref.watch(settingsServiceProvider));
});

class DesktopModeNotifier extends StateNotifier<bool> {
  final SettingsService _settingsService;
  DesktopModeNotifier(this._settingsService) : super(_settingsService.getDesktopModeEnabled());

  Future<void> setDesktopMode(bool enabled) async { // This is for global default
    await _settingsService.setDesktopModeEnabled(enabled);
    state = enabled;
  }
}

final downloadPathProvider = StateNotifierProvider<DownloadPathNotifier, String?>((ref) {
  return DownloadPathNotifier(ref.watch(settingsServiceProvider));
});

class DownloadPathNotifier extends StateNotifier<String?> {
  final SettingsService _settingsService;
  DownloadPathNotifier(this._settingsService) : super(_settingsService.getDownloadPath());

  Future<void> setDownloadPath(String? path) async {
    await _settingsService.setDownloadPath(path);
    state = path;
  }
}


// --- History Providers ---
final historyServiceProvider = Provider<HistoryService>((ref) {
  final box = Hive.box<HistoryItem>(historyBoxName);
  return HistoryService(box);
});

final historyProvider = StreamProvider<List<HistoryItem>>((ref) {
  return ref.watch(historyServiceProvider).getHistoryStream();
});


// --- Browser State Providers (Global for Active Tab) ---
final currentUrlProvider = StateProvider<String>((ref) => "https://www.google.com");
final currentTitleProvider = StateProvider<String>((ref) => "Nebula");
final erudaVisibleProvider = StateProvider<bool>((ref) => false); // Global toggle for Eruda


// --- Find in Page Providers ---
final findInPageVisibleProvider = StateProvider<bool>((ref) => false);
final findInPageQueryProvider = StateProvider<String>((ref) => "");
final findInPageResultsProvider = StateProvider<FindAllAsyncResult?>((ref) => null);
final findInPageActiveMatchOrdinalProvider = StateProvider<int>((ref) => 0);


// --- Tab Management Providers ---
final tabListProvider = StateNotifierProvider<TabListNotifier, List<TabModel>>((ref) {
  return TabListNotifier(ref);
});

final activeTabIndexProvider = StateProvider<int>((ref) {
  // Ensure initial active tab index is valid if tabs exist
  final tabs = ref.watch(tabListProvider);
  return tabs.isNotEmpty ? 0 : -1; // -1 if no tabs, though notifier adds one
});

final activeTabProvider = Provider<TabModel?>((ref) {
  final tabs = ref.watch(tabListProvider);
  final activeIndex = ref.watch(activeTabIndexProvider);
  if (tabs.isNotEmpty && activeIndex >= 0 && activeIndex < tabs.length) {
    return tabs[activeIndex];
  }
  return null;
});

class TabListNotifier extends StateNotifier<List<TabModel>> {
  final Ref _ref;
  final Uuid _uuid = const Uuid();

  TabListNotifier(this._ref) : super([]) {
    if (state.isEmpty) {
      addNewTab(initialUrl: "https://www.google.com", activate: true);
    }
  }

  void addNewTab({String initialUrl = "about:blank", bool activate = true, bool? useDesktopMode}) {
    final newTab = TabModel(
      id: _uuid.v4(),
      url: initialUrl,
      webViewKey: GlobalKey<InAppWebViewState>(),
      isDesktopMode: useDesktopMode ?? _ref.read(desktopModeProvider) // Use global default
    );
    state = [...state, newTab];
    if (activate) {
      _ref.read(activeTabIndexProvider.notifier).state = state.length - 1;
    }
  }

  void closeTab(String tabId) {
    final tabIndex = state.indexWhere((tab) => tab.id == tabId);
    if (tabIndex == -1) return;

    state[tabIndex].dispose(); // Clean up tab-specific resources (like PullToRefreshController)
    
    final List<TabModel> newState = state.where((tab) => tab.id != tabId).toList();
    
    int currentActiveIndex = _ref.read(activeTabIndexProvider);

    if (newState.isEmpty) {
      // Add a new default tab and make it active
      final newDefaultTab = TabModel(
        id: _uuid.v4(),
        url: "https://www.google.com",
        webViewKey: GlobalKey<InAppWebViewState>(),
        isDesktopMode: _ref.read(desktopModeProvider)
      );
      state = [newDefaultTab];
      _ref.read(activeTabIndexProvider.notifier).state = 0;
    } else {
      state = newState;
      if (currentActiveIndex == tabIndex) {
        // If the closed tab was active, activate the previous one, or the first one.
        _ref.read(activeTabIndexProvider.notifier).state = (tabIndex > 0) ? tabIndex - 1 : 0;
      } else if (currentActiveIndex > tabIndex) {
        // If an earlier tab was closed, decrement the active index.
        _ref.read(activeTabIndexProvider.notifier).state = currentActiveIndex - 1;
      }
      // If a later tab was closed, active index remains valid.
    }
  }

  void updateTabController(String tabId, InAppWebViewController controller) {
    state = [
      for (final tab in state)
        if (tab.id == tabId) tab..webViewController = controller else tab,
    ];
  }

  void updateTabDetails(String tabId, {
    String? url, String? title, double? progress,
    bool? canGoBack, bool? canGoForward, WebUri? faviconUrl, bool? isErudaInjected, String? originalUserAgent
  }) {
     state = [
      for (final tab in state)
        if (tab.id == tabId)
          tab
            ..url = url ?? tab.url
            ..title = title ?? tab.title
            ..progress = progress ?? tab.progress
            ..canGoBack = canGoBack ?? tab.canGoBack
            ..canGoForward = canGoForward ?? tab.canGoForward
            ..faviconUrl = faviconUrl ?? tab.faviconUrl
            ..isErudaInjected = isErudaInjected ?? tab.isErudaInjected
            ..originalUserAgent = originalUserAgent ?? tab.originalUserAgent
        else
          tab,
    ];
    final activeTab = _ref.read(activeTabProvider); // Read fresh value after state update
    if (activeTab?.id == tabId) {
      if (url != null) _ref.read(currentUrlProvider.notifier).state = url;
      if (title != null) _ref.read(currentTitleProvider.notifier).state = title;
    }
  }

   void updateTabDesktopMode(String tabId, bool isDesktop) {
    state = [
      for (final tab in state)
        if (tab.id == tabId) tab..isDesktopMode = isDesktop else tab,
    ];
  }
}