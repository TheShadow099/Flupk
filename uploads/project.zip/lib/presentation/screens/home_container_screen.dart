import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nebula/presentation/screens/browser/browser_screen.dart';
import 'package:nebula/presentation/screens/downloads/downloads_screen.dart';
import 'package:nebula/presentation/screens/history/history_screen.dart';
import 'package:nebula/presentation/screens/settings/settings_screen.dart';
import 'package:nebula/presentation/widgets/app_drawer.dart';

// Provider for selected screen index (moved from HomeContainerScreen for global access if needed elsewhere)
final selectedScreenIndexProvider = StateProvider<int>((ref) => 0);

class HomeContainerScreen extends StatefulWidget {
  final bool showInitialLoadingAnimation;
  const HomeContainerScreen({super.key, this.showInitialLoadingAnimation = false});

  @override
  State<HomeContainerScreen> createState() => _HomeContainerScreenState();
}

class _HomeContainerScreenState extends State<HomeContainerScreen> with SingleTickerProviderStateMixin {
  bool _isInitialLoading = false;
  late AnimationController _loadingAnimationController;
  late Animation<double> _fadeAnimation;

  static final List<Widget> _screens = [
    const BrowserScreen(),
    const HistoryScreen(),
    const DownloadsScreen(),
    const SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _isInitialLoading = widget.showInitialLoadingAnimation;

    _loadingAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600), // Fade out duration
    );
    // Use an ease-in-out curve for smoother fade
    _fadeAnimation = CurvedAnimation(parent: _loadingAnimationController, curve: Curves.easeInOut);

    if (_isInitialLoading) {
      // Duration for the loading bar to be visible before starting to fade
      Future.delayed(const Duration(seconds: 1, milliseconds: 500), () {
        if (mounted) {
          _loadingAnimationController.forward(); // Start fading out
          _loadingAnimationController.addStatusListener((status) {
            if (status == AnimationStatus.completed) {
              if (mounted) {
                setState(() {
                  _isInitialLoading = false;
                });
              }
            }
          });
        }
      });
    }
  }

  @override
  void dispose() {
    _loadingAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer(builder: (context, ref, child) {
      final selectedIndex = ref.watch(selectedScreenIndexProvider);
      final theme = Theme.of(context);

      return Scaffold(
        drawer: const AppDrawer(),
        body: Stack(
          children: [
            IndexedStack(
              index: selectedIndex,
              children: _screens,
            ),
            if (_isInitialLoading)
              // Use IgnorePointer to prevent interaction with the loading overlay
              IgnorePointer(
                ignoring: !_isInitialLoading, // Allow interaction when not loading
                child: FadeTransition(
                  opacity: ReverseAnimation(_fadeAnimation), // Reverse for fade-out effect
                  child: Container(
                    color: theme.scaffoldBackgroundColor.withOpacity(0.98), // Slightly more opaque
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset('assets/images/nebula_logo.png', height: 70),
                          const SizedBox(height: 20),
                          Text(
                            "Nebula is waking up...", 
                            style: theme.textTheme.titleMedium?.copyWith(color: theme.textTheme.bodySmall?.color)
                          ),
                          const SizedBox(height: 25),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.55,
                            child: LinearProgressIndicator(
                              backgroundColor: theme.dividerColor,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  theme.colorScheme.secondary),
                              minHeight: 3.5, // Slightly thicker
                              borderRadius: BorderRadius.circular(5), // Rounded edges
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      );
    });
  }
}