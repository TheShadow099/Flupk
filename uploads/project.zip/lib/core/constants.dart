const String historyBoxName = 'historyBox';
const String settingsBoxName = 'settingsBox';

// Setting Keys
const String themeModeKey = 'themeMode';
const String saveHistoryKey = 'saveHistory';
const String downloadPathKey = 'downloadPath';
const String firstLaunchKey = 'isFirstLaunch';
const String desktopModeKey = 'desktopModeEnabled'; // Global default for new tabs

// Eruda Script (Basic CDN version)
const String erudaScript = """
  (function () {
    var script = document.createElement('script');
    script.src = "//cdn.jsdelivr.net/npm/eruda";
    document.body.appendChild(script);
    script.onload = function () {
      eruda.init();
      // eruda.show(); // Uncomment to show by default
    }
  })();
""";