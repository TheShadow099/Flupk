import 'package:flutter/material.dart';

class DialogUtils {
  static Future<void> showAlertDialog(BuildContext context, String title, String message, String buttonText) {
    return showDialog<void>(
      context: context,
      barrierDismissible: true, // Allow dismissing by tapping outside for simple alerts
      builder: (BuildContext dialogContext) { // Use different context name
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
          title: Text(title),
          content: SingleChildScrollView(child: Text(message)),
          actions: <Widget>[
            TextButton(
              child: Text(buttonText),
              onPressed: () {
                Navigator.of(dialogContext).pop();
              },
            ),
          ],
        );
      },
    );
  }

  static Future<bool> showConfirmDialog(
    BuildContext context, String title, String message, String confirmText, String cancelText) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false, // User must choose for confirmation
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text(cancelText, style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color)),
              onPressed: () {
                Navigator.of(dialogContext).pop(false);
              },
            ),
            TextButton(
              child: Text(confirmText, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
              onPressed: () {
                Navigator.of(dialogContext).pop(true);
              },
            ),
          ],
        );
      },
    );
    return result ?? false; // If dialog is dismissed programmatically without a value, return false
  }

  static Future<String?> showPromptDialog(
      BuildContext context, String title, String message, String initialValue, String confirmText, String cancelText) async {
    TextEditingController controller = TextEditingController(text: initialValue);
    return showDialog<String>(
      context: context,
      barrierDismissible: false, // User must choose for prompt
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
          title: Text(title),
          content: Column(
            mainAxisSize: MainAxisSize.min, // Important for Column in AlertDialog
            children: [
              if (message.isNotEmpty) Text(message),
              if (message.isNotEmpty) const SizedBox(height: 12),
              TextField(
                controller: controller,
                autofocus: true,
                decoration: InputDecoration(
                  hintText: "Enter value", // Generic hint
                  // border: OutlineInputBorder(), // Optional: more defined border
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: Text(cancelText, style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color)),
              onPressed: () => Navigator.of(dialogContext).pop(null),
            ),
            TextButton(
              child: Text(confirmText, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold)),
              onPressed: () => Navigator.of(dialogContext).pop(controller.text),
            ),
          ],
        );
      },
    );
  }
}