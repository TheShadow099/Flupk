import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:nebula/core/download_manager.dart';
import 'package:nebula/utils/dialog_utils.dart';
import 'package:nebula/utils/file_utils.dart';
import 'package:path/path.dart' as p;

class DownloadsScreen extends ConsumerWidget {
  const DownloadsScreen({super.key});

  Widget _buildTaskStatus(DownloadTask task, BuildContext context) {
    Color statusColor = Theme.of(context).textTheme.bodySmall?.color ?? Colors.grey;
    String statusText = task.status.toString().split('.').last.toUpperCase();

    switch(task.status) {
      case DownloadTaskStatus.running:
        return LinearProgressIndicator(
            value: task.progress / 100, 
            backgroundColor: Theme.of(context).dividerColor,
            valueColor: AlwaysStoppedAnimation<Color>(Theme.of(context).colorScheme.secondary),
            minHeight: 5,
        );
      case DownloadTaskStatus.paused:
        statusColor = Colors.orange.shade700;
        statusText = 'PAUSED (${task.progress}%)';
        break;
      case DownloadTaskStatus.complete:
        statusColor = Colors.green.shade700;
        statusText = 'COMPLETED';
        break;
      case DownloadTaskStatus.failed:
        statusColor = Theme.of(context).colorScheme.error;
        statusText = 'FAILED';
        break;
      case DownloadTaskStatus.canceled:
        statusColor = Colors.grey.shade600;
        statusText = 'CANCELED';
        break;
      case DownloadTaskStatus.enqueued:
        statusColor = Theme.of(context).colorScheme.primary;
        statusText = 'ENQUEUED';
        break;
      default:
        break;
    }
    return Text(statusText, style: TextStyle(fontSize: 12, color: statusColor, fontWeight: FontWeight.w500));
  }

  IconData _getTaskIcon(DownloadTaskStatus status) {
    if (status == DownloadTaskStatus.running) return Icons.downloading_rounded;
    if (status == DownloadTaskStatus.paused) return Icons.pause_circle_outline_rounded;
    if (status == DownloadTaskStatus.complete) return Icons.check_circle_outline_rounded;
    if (status == DownloadTaskStatus.failed) return Icons.error_outline_rounded;
    if (status == DownloadTaskStatus.canceled) return Icons.cancel_outlined;
    return Icons.hourglass_empty_rounded;
  }

  Color _getTaskIconColor(BuildContext context, DownloadTaskStatus status) {
    if (status == DownloadTaskStatus.complete) return Colors.green.shade600;
    if (status == DownloadTaskStatus.failed) return Theme.of(context).colorScheme.error;
    if (status == DownloadTaskStatus.paused) return Colors.orange.shade600;
    return Theme.of(context).colorScheme.primary;
  }

  void _showDownloadActions(BuildContext context, WidgetRef ref, DownloadTask task) {
    final manager = ref.read(downloadManagerProvider);
    final String filePath = "${task.savedDir}/${task.filename}"; // filename can be null

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16.0))
      ),
      builder: (BuildContext ctx) {
        return Padding(
          padding: const EdgeInsets.only(bottom: 8.0, top: 8.0),
          child: Wrap(
            children: <Widget>[
              if (task.status == DownloadTaskStatus.complete && task.filename != null)
                ListTile(
                  leading: const Icon(Icons.open_in_new_outlined), title: const Text('Open File'),
                  onTap: () { Navigator.pop(ctx); manager.openDownloadedFile(task.taskId); },
                ),
              if (task.status == DownloadTaskStatus.running)
                ListTile(
                  leading: const Icon(Icons.pause_circle_outline), title: const Text('Pause'),
                  onTap: () { Navigator.pop(ctx); manager.pauseDownload(task.taskId); },
                ),
              if (task.status == DownloadTaskStatus.paused)
                ListTile(
                  leading: const Icon(Icons.play_circle_outline), title: const Text('Resume'),
                  onTap: () { Navigator.pop(ctx); manager.resumeDownload(task.taskId); },
                ),
              if (task.status == DownloadTaskStatus.failed || task.status == DownloadTaskStatus.canceled || task.status == DownloadTaskStatus.paused)
                ListTile(
                  leading: const Icon(Icons.replay_circle_filled_outlined), title: const Text('Retry'),
                  onTap: () { Navigator.pop(ctx); manager.retryDownload(task.taskId); },
                ),
              ListTile(
                leading: const Icon(Icons.info_outline), title: const Text('Info'),
                onTap: () async {
                  Navigator.pop(ctx);
                  String info = "Filename: ${task.filename ?? 'N/A'}\nURL: ${task.url}\nStatus: ${task.status.name.toUpperCase()}";
                  info += "\nSaved to: ${task.savedDir}";
                  info += "\nTask ID: ${task.taskId}\nProgress: ${task.progress}%";
                  info += "\nTime Created: ${DateFormat.yMMMd().add_jm().format(DateTime.fromMillisecondsSinceEpoch(task.timeCreated))}";
                  if (task.status == DownloadTaskStatus.complete && task.filename != null) {
                    final fileStat = await FileUtils.getFileInfo(filePath); // Use task.filename here
                    if (fileStat != null) info += "\nSize: ${(fileStat.size / (1024 * 1024)).toStringAsFixed(2)} MB";
                  }
                  if (ctx.mounted) DialogUtils.showAlertDialog(ctx, "Download Info", info, "OK");
                },
              ),
              ListTile(
                leading: Icon(Icons.delete_sweep_outlined, color: Theme.of(ctx).colorScheme.error),
                title: Text('Delete Entry & File', style: TextStyle(color: Theme.of(ctx).colorScheme.error)),
                onTap: () async {
                  Navigator.pop(ctx);
                  final confirmed = await DialogUtils.showConfirmDialog(ctx, "Delete Download",
                      "Delete '${task.filename ?? task.taskId}' and its downloaded file?", "Delete", "Cancel");
                  if (confirmed) {
                    await manager.removeDownload(task.taskId, true);
                    if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text("'${task.filename ?? task.taskId}' deleted.")));
                  }
                },
              ),
               ListTile(
                leading: Icon(Icons.delete_outline, color: Theme.of(ctx).colorScheme.error.withOpacity(0.7)),
                title: Text('Delete Entry Only', style: TextStyle(color: Theme.of(ctx).colorScheme.error.withOpacity(0.7))),
                onTap: () async {
                  Navigator.pop(ctx);
                  final confirmed = await DialogUtils.showConfirmDialog(ctx, "Remove Entry",
                      "Remove '${task.filename ?? task.taskId}' from list? The downloaded file will remain.", "Remove", "Cancel");
                  if (confirmed) {
                    await manager.removeDownload(task.taskId, false); // false to keep content
                     if (ctx.mounted) ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text("'${task.filename ?? task.taskId}' removed from list.")));
                  }
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncTasks = ref.watch(downloadTasksProvider);
    final manager = ref.read(downloadManagerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Downloads'),
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: () => Scaffold.of(context).openDrawer()),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_outlined), tooltip: "Refresh Downloads List",
            onPressed: () async => await manager.refreshDownloadTasks(),
          )
        ],
      ),
      body: asyncTasks.when(
        data: (tasks) {
          if (tasks.isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.file_download_off_outlined, size: 70, color: Colors.grey),
                  SizedBox(height: 16),
                  Text('No downloads yet.', style: TextStyle(fontSize: 18, color: Colors.grey)),
                ],
              ),
            );
          }
          tasks.sort((a, b) => b.timeCreated.compareTo(a.timeCreated));

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8.0),
            itemCount: tasks.length,
            itemBuilder: (context, index) {
              final task = tasks[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                elevation: 1.5,
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  leading: Icon(_getTaskIcon(task.status), color: _getTaskIconColor(context, task.status), size: 30),
                  title: Text(task.filename ?? p.basename(task.url), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w500)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 5),
                      _buildTaskStatus(task, context),
                      const SizedBox(height: 3),
                      Text(
                        "Queued: ${DateFormat.yMMMd().add_jm().format(DateTime.fromMillisecondsSinceEpoch(task.timeCreated))}",
                        style: TextStyle(fontSize: 10.5, color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.7)),
                      ),
                      if (task.filename != null)
                        Text(
                          "Path: ${task.savedDir}", maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 10.5, color: Theme.of(context).textTheme.bodySmall?.color?.withOpacity(0.7)),
                        ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.more_vert_outlined),
                    tooltip: "Download actions",
                    onPressed: () => _showDownloadActions(context, ref, task),
                  ),
                  onTap: (task.status == DownloadTaskStatus.complete && task.filename != null)
                      ? () => manager.openDownloadedFile(task.taskId)
                      : (task.status == DownloadTaskStatus.paused || task.status == DownloadTaskStatus.failed)
                          ? () => manager.resumeDownload(task.taskId) // Or retry if failed
                          : null,
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, stack) => Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Error loading downloads: $err\nMake sure FlutterDownloader is correctly setup.', textAlign: TextAlign.center),
          )
        ),
      ),
    );
  }
}