import 'dart:io';
import 'package:open_file_plus/open_file_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart'; // For permissions if needed by this util

class FileUtils {
  static Future<Directory?> getPublicDownloadsDirectory() async {
    if (Platform.isAndroid) {
      // For Android, getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS) is preferred.
      // path_provider doesn't directly expose this for public directories robustly across all SDKs.
      // A common approach is to use getExternalStorageDirectory and append "Download".
      // This requires storage permission.
      try {
        final directory = await getExternalStorageDirectory(); // This gives /storage/emulated/0/Android/data/<package>/files
        if (directory != null) {
          // To get to public "Downloads", we usually go up from app-specific external storage.
          // This is not reliable and can break.
          // A better approach for public downloads on Android is via platform channels or specific plugins if flutter_downloader isn't used.
          // For flutter_downloader, it handles saving to public "Downloads" if specified.
          // If we are *not* using flutter_downloader and want to save here, it's more complex.
          // For now, let's assume this is for app's "external" but still sandboxed files.
          
          // If you truly want the public "Downloads" folder outside app sandbox:
          // This would typically be /storage/emulated/0/Download
          // One less reliable way:
          // String? externalStoragePath = directory.parent.parent.parent.parent.path; // Moves up from /Android/data/<package>/files
          // if (externalStoragePath != null) {
          //   final publicDownloadsDir = Directory("$externalStoragePath/Download");
          //    if (!await publicDownloadsDir.exists()) {
          //       await publicDownloadsDir.create(recursive: true);
          //    }
          //   return publicDownloadsDir;
          // }
          
          // A safer bet for "external" but still app-specific:
          final appExternalDownloadsDir = Directory("${directory.path}/NebulaDownloads");
           if (!await appExternalDownloadsDir.exists()) {
              await appExternalDownloadsDir.create(recursive: true);
           }
          return appExternalDownloadsDir;

        }
      } catch (e) {
        print("Error getting external storage directory: $e");
        // Fallback to application documents directory for safety
        return getApplicationDocumentsDirectory();
      }
    } else if (Platform.isIOS) {
      // iOS apps are sandboxed; typically use getApplicationDocumentsDirectory for "downloads"
      return getApplicationDocumentsDirectory();
    }
    // Fallback for other platforms or if path couldn't be determined
    return getApplicationSupportDirectory(); // Or documents
  }

  // requestStoragePermissions is now primarily handled by DownloadManager or specific features needing it.
  // This utility can be kept simple.

  static Future<void> openFile(String filePath) async {
    print("Attempting to open file: $filePath");
    final OpenResult result = await OpenFile.open(filePath);
    if (result.type != ResultType.done) {
      print('Error opening file: ${result.message} (Type: ${result.type})');
      // Optionally show a snackbar or dialog to the user if context is available
      // e.g., ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not open file: ${result.message}')));
    }
  }

  static Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        print("File deleted: $filePath");
        return true;
      }
      print("File not found for deletion: $filePath");
      return false;
    } catch (e) {
      print("Error deleting file $filePath: $e");
      return false;
    }
  }

  static Future<FileStat?> getFileInfo(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        return await file.stat();
      }
    } catch (e) {
      print("Error getting file info for $filePath: $e");
    }
    return null;
  }

  static Future<String?> renameFile(String oldPath, String newNameWithExtension) async {
    try {
      final oldFile = File(oldPath);
      if (await oldFile.exists()) {
        String dir = oldFile.parent.path;
        // Ensure newNameWithExtension is just the name and extension, not a path
        String newFileName = newNameWithExtension.replaceAll(RegExp(r'[/\\]'), ''); // Sanitize
        if (newFileName.isEmpty) {
          print("New filename cannot be empty.");
          return null;
        }
        String newPath = "$dir/$newFileName";
        
        if (await File(newPath).exists()) {
          print("File with new name already exists: $newPath. Cannot rename.");
          return null; // Or implement logic to append (1), (2), etc.
        }
        
        final renamedFile = await oldFile.rename(newPath);
        print("File renamed from $oldPath to ${renamedFile.path}");
        return renamedFile.path;
      } else {
        print("Old file not found for rename: $oldPath");
      }
    } catch (e) {
      print("Error renaming file $oldPath to $newNameWithExtension: $e");
    }
    return null;
  }
}