import 'package:flutter/material.dart';
import 'package:nebula/core/constants.dart';
import 'package:nebula/presentation/screens/home_container_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';

class IntroSplashScreen extends StatelessWidget {
  const IntroSplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final Color primaryTextColor = theme.textTheme.displayLarge?.color ?? (theme.brightness == Brightness.dark ? Colors.white : Colors.black87);
    final Color secondaryTextColor = theme.textTheme.bodyMedium?.color ?? (theme.brightness == Brightness.dark ? Colors.grey[400]! : Colors.grey[700]!);

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Image.asset(
                'assets/images/nebula_logo.png',
                height: 100.0, // Adjusted size
              ),
              const SizedBox(height: 24.0),
              Text(
                'Nebula Browser',
                textAlign: TextAlign.center,
                style: GoogleFonts.orbitron(
                  fontSize: 28.0, // Adjusted size
                  fontWeight: FontWeight.bold,
                  color: primaryTextColor,
                  letterSpacing: 1.1,
                ),
              ),
              const SizedBox(height: 12.0),
              Text(
                'Explore the Web, Beyond Limits.',
                textAlign: TextAlign.center,
                style: GoogleFonts.roboto(
                  fontSize: 17.0, // Adjusted size
                  color: secondaryTextColor,
                  fontStyle: FontStyle.italic,
                ),
              ),
              const SizedBox(height: 60.0), // Increased spacing
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary, // Use theme color
                  foregroundColor: theme.colorScheme.onPrimary,
                  padding: const EdgeInsets.symmetric(horizontal: 48, vertical: 16), // Adjusted padding
                  textStyle: GoogleFonts.roboto(
                    fontSize: 17, // Adjusted size
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.5,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0),
                  ),
                  elevation: 3,
                ),
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool(firstLaunchKey, false);
                  if (context.mounted) {
                    Navigator.pushReplacement(
                      context,
                      PageRouteBuilder(
                        pageBuilder: (context, animation, secondaryAnimation) =>
                            const HomeContainerScreen(showInitialLoadingAnimation: true),
                        transitionsBuilder: (context, animation, secondaryAnimation, child) {
                          return FadeTransition(opacity: animation, child: child);
                        },
                        transitionDuration: const Duration(milliseconds: 500), // Added duration
                      ),
                    );
                  }
                },
                child: const Text('GET STARTED'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}